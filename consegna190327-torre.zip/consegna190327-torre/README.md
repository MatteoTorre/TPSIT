# FillZone OR Jeweled

Viene proposta la realizzazione, in alternativa, di uno dei due giochi: "FillZOne" e "Jeweled".

## Valutazione

Oltre alla pulizia del codice, alla documentazione ed alle scelte operate il progetto
deve essere consegnato in una cartella `FillZone` o `Jeweled` che contenga il file `README.md` in cui si dà breve descrizione del progetto con attenzione alle scelte operate. Le valutazioni eccellenti (8, 9, 10) deriveranno da un consistente apporto personale e creativo: uso di animazioni ed altro, stile adottato ecc..
