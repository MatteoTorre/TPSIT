package com.example.fillzone;


import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    ObjectAnimator rotateMe;
    public static final String EXTRA_PARTITA = "com.example.andre.tictactoe.MainActivity.EXTRA_PARTITA";

    public void aggiorna(Button[][] tabella, FillZone gioco, int partita) {
        for (int i = 0; i < partita; i++) {
            for (int j = 0; j < partita; j++) {
                switch (gioco.getTab()[i][j]) {
                    case 0:
                        tabella[i][j].setBackgroundColor(Color.RED);
                        break;
                    case 1:
                        tabella[i][j].setBackgroundColor(Color.BLUE);
                        break;
                    case 2:
                        tabella[i][j].setBackgroundColor(Color.YELLOW);
                        break;
                    case 3:
                        tabella[i][j].setBackgroundColor(Color.GREEN);
                        break;
                    case 4:
                        tabella[i][j].setBackgroundColor(Color.WHITE);
                        break;
                }
            }
        }
    }

    public void ruota(int[][] tabellaVecchia, FillZone gioco, Button[][] tabella) {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                if (tabellaVecchia[i][j] != gioco.getTab()[i][j]) {
                    rotate(tabella, i, j);
                }
            }
        }
    }

    public void ingrandisci(int[][] tabellaVecchia, FillZone gioco, Button[][] tabella, MediaPlayer mp, int partita) {
        for (int i = 0; i < partita; i++) {
            for (int j = 0; j < partita; j++) {
                if (tabellaVecchia[i][j] != gioco.getTab()[i][j]) {
                    maxMin(tabella, i, j, mp);
                }
            }
        }
    }

    public void caricaTabellaVecchia(int[][] tabellaVecchia, FillZone gioco, int partita) {
        for (int i = 0; i < partita; i++) {
            for (int j = 0; j < partita; j++) {
                tabellaVecchia[i][j] = gioco.getTab()[i][j];
            }
        }
    }


    public void gioca(FillZone gioco, Button[][] tabella, TextView nMosse, int[][] tabellaVecchia, int coloreNuovo, int coloreVecchio, MediaPlayer mp, int partita) {
        boolean ris = gioco.mossa(coloreNuovo, coloreVecchio);
        int mosse = gioco.getMosse();
        if (ris || mosse == 0) {
            int mosseRestanti = gioco.getMosse();
            nMosse.setText(String.valueOf(mosseRestanti));
            ingrandisci(tabellaVecchia, gioco, tabella, mp, partita);
            aggiorna(tabella, gioco, partita);
            caricaTabellaVecchia(tabellaVecchia, gioco, partita);
            final Dialog dialog = new Dialog(this); // Context, this, etc.
            if (mosse <= 0) {
                dialog.setCancelable(false);
                dialog.setContentView(R.layout.dialog_demo);
                TextView tTitle = dialog.findViewById(R.id.dialog_title);
                tTitle.setText(R.string.lose);
                TextView tLose = dialog.findViewById(R.id.dialog_info);
                tLose.setText(R.string.lose_message);
            } else {
                dialog.setCancelable(false);
                dialog.setContentView(R.layout.dialog_demo);
                TextView tTitle = dialog.findViewById(R.id.dialog_title);
                tTitle.setText(R.string.win);
                TextView tWin = dialog.findViewById(R.id.dialog_info);
                tWin.setText(R.string.win_message);
            }
            Button bRestart = (Button) dialog.findViewById(R.id.dialog_ok);
            Button bQuit = (Button) dialog.findViewById(R.id.dialog_cancel);
            bRestart.setOnClickListener(
                    (View v) -> {
                        gioco.reset();
                        aggiorna(tabella, gioco,partita);
                        caricaTabellaVecchia(tabellaVecchia, gioco, partita);
                        nMosse.setText(String.valueOf(gioco.getMosse()));
                        dialog.hide();
                    });
            bQuit.setOnClickListener(
                    (View v) -> {
                        this.finish();
                        dialog.hide();
                    }
            );
            dialog.show();
        } else {
            int mosseRestanti = gioco.getMosse();
            nMosse.setText(String.valueOf(mosseRestanti));
            ingrandisci(tabellaVecchia, gioco, tabella, mp, partita);
            aggiorna(tabella, gioco, partita);
            caricaTabellaVecchia(tabellaVecchia, gioco, partita);
        }

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent sceltaRicevuta = getIntent();//intent che riceve la tipologia di partita selezionata dall'utente
        int partita = sceltaRicevuta.getIntExtra(ActivityScelta.EXTRA_PARTITA, 0);
        FillZone gioco;
        Button[][] tabella;
        int tabellaVecchia[][];

        if(partita == 10){setContentView(R.layout.activity_10x10);
            gioco = new FillZone(10,10);
            tabellaVecchia = new int[10][10];
            tabella = new Button[10][10];

            tabella[0][0] = findViewById(R.id.button0);
            tabella[0][1] = findViewById(R.id.button1);
            tabella[0][2] = findViewById(R.id.button2);
            tabella[0][3] = findViewById(R.id.button3);
            tabella[0][4] = findViewById(R.id.button4);
            tabella[0][5] = findViewById(R.id.button5);
            tabella[0][6] = findViewById(R.id.button6);
            tabella[0][7] = findViewById(R.id.button7);
            tabella[0][8] = findViewById(R.id.button8);
            tabella[0][9] = findViewById(R.id.button9);

            tabella[1][0] = findViewById(R.id.button10);
            tabella[1][1] = findViewById(R.id.button11);
            tabella[1][2] = findViewById(R.id.button12);
            tabella[1][3] = findViewById(R.id.button13);
            tabella[1][4] = findViewById(R.id.button14);
            tabella[1][5] = findViewById(R.id.button15);
            tabella[1][6] = findViewById(R.id.button16);
            tabella[1][7] = findViewById(R.id.button17);
            tabella[1][8] = findViewById(R.id.button18);
            tabella[1][9] = findViewById(R.id.button19);

            tabella[2][0] = findViewById(R.id.button20);
            tabella[2][1] = findViewById(R.id.button21);
            tabella[2][2] = findViewById(R.id.button22);
            tabella[2][3] = findViewById(R.id.button23);
            tabella[2][4] = findViewById(R.id.button24);
            tabella[2][5] = findViewById(R.id.button25);
            tabella[2][6] = findViewById(R.id.button26);
            tabella[2][7] = findViewById(R.id.button27);
            tabella[2][8] = findViewById(R.id.button28);
            tabella[2][9] = findViewById(R.id.button29);

            tabella[3][0] = findViewById(R.id.button30);
            tabella[3][1] = findViewById(R.id.button31);
            tabella[3][2] = findViewById(R.id.button32);
            tabella[3][3] = findViewById(R.id.button33);
            tabella[3][4] = findViewById(R.id.button34);
            tabella[3][5] = findViewById(R.id.button35);
            tabella[3][6] = findViewById(R.id.button36);
            tabella[3][7] = findViewById(R.id.button37);
            tabella[3][8] = findViewById(R.id.button38);
            tabella[3][9] = findViewById(R.id.button39);

            tabella[4][0] = findViewById(R.id.button40);
            tabella[4][1] = findViewById(R.id.button41);
            tabella[4][2] = findViewById(R.id.button42);
            tabella[4][3] = findViewById(R.id.button43);
            tabella[4][4] = findViewById(R.id.button44);
            tabella[4][5] = findViewById(R.id.button45);
            tabella[4][6] = findViewById(R.id.button46);
            tabella[4][7] = findViewById(R.id.button47);
            tabella[4][8] = findViewById(R.id.button48);
            tabella[4][9] = findViewById(R.id.button49);

            tabella[5][0] = findViewById(R.id.button50);
            tabella[5][1] = findViewById(R.id.button51);
            tabella[5][2] = findViewById(R.id.button52);
            tabella[5][3] = findViewById(R.id.button53);
            tabella[5][4] = findViewById(R.id.button54);
            tabella[5][5] = findViewById(R.id.button55);
            tabella[5][6] = findViewById(R.id.button56);
            tabella[5][7] = findViewById(R.id.button57);
            tabella[5][8] = findViewById(R.id.button58);
            tabella[5][9] = findViewById(R.id.button59);

            tabella[6][0] = findViewById(R.id.button60);
            tabella[6][1] = findViewById(R.id.button61);
            tabella[6][2] = findViewById(R.id.button62);
            tabella[6][3] = findViewById(R.id.button63);
            tabella[6][4] = findViewById(R.id.button64);
            tabella[6][5] = findViewById(R.id.button65);
            tabella[6][6] = findViewById(R.id.button66);
            tabella[6][7] = findViewById(R.id.button67);
            tabella[6][8] = findViewById(R.id.button68);
            tabella[6][9] = findViewById(R.id.button69);

            tabella[7][0] = findViewById(R.id.button70);
            tabella[7][1] = findViewById(R.id.button71);
            tabella[7][2] = findViewById(R.id.button72);
            tabella[7][3] = findViewById(R.id.button73);
            tabella[7][4] = findViewById(R.id.button74);
            tabella[7][5] = findViewById(R.id.button75);
            tabella[7][6] = findViewById(R.id.button76);
            tabella[7][7] = findViewById(R.id.button77);
            tabella[7][8] = findViewById(R.id.button78);
            tabella[7][9] = findViewById(R.id.button79);

            tabella[8][0] = findViewById(R.id.button80);
            tabella[8][1] = findViewById(R.id.button81);
            tabella[8][2] = findViewById(R.id.button82);
            tabella[8][3] = findViewById(R.id.button83);
            tabella[8][4] = findViewById(R.id.button84);
            tabella[8][5] = findViewById(R.id.button85);
            tabella[8][6] = findViewById(R.id.button86);
            tabella[8][7] = findViewById(R.id.button87);
            tabella[8][8] = findViewById(R.id.button88);
            tabella[8][9] = findViewById(R.id.button89);

            tabella[9][0] = findViewById(R.id.button90);
            tabella[9][1] = findViewById(R.id.button91);
            tabella[9][2] = findViewById(R.id.button92);
            tabella[9][3] = findViewById(R.id.button93);
            tabella[9][4] = findViewById(R.id.button94);
            tabella[9][5] = findViewById(R.id.button95);
            tabella[9][6] = findViewById(R.id.button96);
            tabella[9][7] = findViewById(R.id.button97);
            tabella[9][8] = findViewById(R.id.button98);
            tabella[9][9] = findViewById(R.id.button99);
        }
        else {
            setContentView(R.layout.activity_5x5);
            tabellaVecchia = new int[5][5];
            gioco = new FillZone(5,5);
            tabella = new Button[5][5];
            tabella[0][0] = findViewById(R.id.button0);
            tabella[0][1] = findViewById(R.id.button1);
            tabella[0][2] = findViewById(R.id.button2);
            tabella[0][3] = findViewById(R.id.button3);
            tabella[0][4] = findViewById(R.id.button4);

            tabella[1][0] = findViewById(R.id.button5);
            tabella[1][1] = findViewById(R.id.button6);
            tabella[1][2] = findViewById(R.id.button7);
            tabella[1][3] = findViewById(R.id.button8);
            tabella[1][4] = findViewById(R.id.button9);

            tabella[2][0] = findViewById(R.id.button10);
            tabella[2][1] = findViewById(R.id.button11);
            tabella[2][2] = findViewById(R.id.button12);
            tabella[2][3] = findViewById(R.id.button13);
            tabella[2][4] = findViewById(R.id.button14);

            tabella[3][0] = findViewById(R.id.button15);
            tabella[3][1] = findViewById(R.id.button16);
            tabella[3][2] = findViewById(R.id.button17);
            tabella[3][3] = findViewById(R.id.button18);
            tabella[3][4] = findViewById(R.id.button19);

            tabella[4][0] = findViewById(R.id.button20);
            tabella[4][1] = findViewById(R.id.button21);
            tabella[4][2] = findViewById(R.id.button22);
            tabella[4][3] = findViewById(R.id.button23);
            tabella[4][4] = findViewById(R.id.button24);
        }


        aggiorna(tabella, gioco, partita);

        Button[] sceltaColore = new Button[5];
        sceltaColore[0] = findViewById(R.id.buttonRed);
        sceltaColore[0].setBackgroundColor(Color.RED);
        sceltaColore[1] = findViewById(R.id.buttonBlue);
        sceltaColore[1].setBackgroundColor(Color.BLUE);
        sceltaColore[2] = findViewById(R.id.buttonYellow);
        sceltaColore[2].setBackgroundColor(Color.YELLOW);
        sceltaColore[3] = findViewById(R.id.buttonGreen);
        sceltaColore[3].setBackgroundColor(Color.GREEN);
        sceltaColore[4] = findViewById(R.id.buttonWhite);
        sceltaColore[4].setBackgroundColor(Color.WHITE);



        TextView nMosse = (TextView) findViewById(R.id.textView3);
        int mosseRest = gioco.getMosse();
        nMosse.setText(String.valueOf(mosseRest));

        final MediaPlayer mp = MediaPlayer.create(this, R.raw.bleep);
        final MediaPlayer mp2 = MediaPlayer.create(this, R.raw.jump);

        sceltaColore[0].setOnClickListener(
                (View v) -> {
                    int coloreNuovo = 0;
                    int coloreVecchio = gioco.getTab()[0][0];
                    caricaTabellaVecchia(tabellaVecchia, gioco, partita);
                    float val = -100;
                    upDown(sceltaColore, 0, val, mp2);
                    gioca(gioco, tabella, nMosse, tabellaVecchia, coloreNuovo, coloreVecchio, mp, partita);
                }
        );

        sceltaColore[1].setOnClickListener(
                (View v) -> {
                    int coloreNuovo = 1;
                    int coloreVecchio = gioco.getTab()[0][0];
                    caricaTabellaVecchia(tabellaVecchia, gioco, partita);
                    float val = -100;
                    upDown(sceltaColore, 1, val, mp2);
                    gioca(gioco, tabella, nMosse, tabellaVecchia, coloreNuovo, coloreVecchio, mp, partita);

                }
        );

        sceltaColore[2].setOnClickListener(
                (View v) -> {
                    int coloreNuovo = 2;
                    int coloreVecchio = gioco.getTab()[0][0];
                    caricaTabellaVecchia(tabellaVecchia, gioco, partita);
                    float val = -100;
                    upDown(sceltaColore, 2, val, mp2);
                    gioca(gioco, tabella, nMosse, tabellaVecchia, coloreNuovo, coloreVecchio, mp, partita);
                }
        );

        sceltaColore[3].setOnClickListener(
                (View v) -> {
                    int coloreNuovo = 3;
                    int coloreVecchio = gioco.getTab()[0][0];
                    caricaTabellaVecchia(tabellaVecchia, gioco, partita);
                    float val = -100;
                    upDown(sceltaColore, 3, val, mp2);
                    gioca(gioco, tabella, nMosse, tabellaVecchia, coloreNuovo, coloreVecchio, mp, partita);
                }
        );

        sceltaColore[4].setOnClickListener(
                (View v) -> {
                    int coloreNuovo = 4;
                    int coloreVecchio = gioco.getTab()[0][0];
                    caricaTabellaVecchia(tabellaVecchia, gioco, partita);
                    float val = -100;
                    upDown(sceltaColore, 4, val, mp2);
                    gioca(gioco, tabella, nMosse, tabellaVecchia, coloreNuovo, coloreVecchio, mp, partita);
                }
        );


    }

    public void rotate(Button[][] tabella, int i, int j) {
        rotateMe = ObjectAnimator.ofFloat(tabella[i][j], "rotation", 0f, 360f);
        rotateMe.setDuration(1000);
        rotateMe.setStartDelay(300);
        rotateMe.start();
    }

    public void upDown(Button[] sceltaColore, int i, float val, MediaPlayer mp2) {
        AnimatorSet as = new AnimatorSet();
        as.playSequentially(ObjectAnimator.ofFloat(sceltaColore[i], "translationY", 0f, val).setDuration(150), // anim 1
                ObjectAnimator.ofFloat(sceltaColore[i], "translationY", val, 0f).setDuration(100), // anim 2
                ObjectAnimator.ofFloat(sceltaColore[i], "translationY", 0f, val / 2).setDuration(50), // anim 3
                ObjectAnimator.ofFloat(sceltaColore[i], "translationY", val / 2, 0f).setDuration(50), // 4
                ObjectAnimator.ofFloat(sceltaColore[i], "translationY", 0f, val / 4).setDuration(50), // 5
                ObjectAnimator.ofFloat(sceltaColore[i], "translationY", val / 4, 0f).setDuration(50)); // anim 6
        as.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animation) {
                super.onAnimationStart(animation);
                //mp2.start();
            }
        });

        as.start();
    }

    public void maxMin(Button[][] tabella, int i, int j, MediaPlayer mp) {
        AnimatorSet as = new AnimatorSet();
        as.playSequentially(
                ObjectAnimator.ofFloat(tabella[i][j], "scaleX", 0.5f).setDuration(50), // anim 1
                ObjectAnimator.ofFloat(tabella[i][j], "scaleY", 0.5f).setDuration(50), // anim 2
                ObjectAnimator.ofFloat(tabella[i][j], "scaleX", 1f).setDuration(50), // anim 3
                ObjectAnimator.ofFloat(tabella[i][j], "scaleY", 1f).setDuration(50));// 4
        as.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animation) {
                super.onAnimationStart(animation);
                mp.start();
            }
        });
        as.start();
    }
}
