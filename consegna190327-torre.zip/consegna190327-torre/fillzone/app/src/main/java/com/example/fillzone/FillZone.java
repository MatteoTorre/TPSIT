package com.example.fillzone;

import android.graphics.Color;
import android.os.Handler;
import android.widget.Button;

import java.util.Random;

public class FillZone {

    private int[][] tab;
    private int mosse;
    private int righe;
    private int colonne;

    public int[][] getTab() {
        return tab;
    }

    public int getMosse() {
        return mosse;
    }

    public FillZone(int righe, int colonne) {
        tab = new int[righe][colonne];
        if(righe == 10) this.mosse = 20;
        else this.mosse = 10;
        this.righe = righe;
        this.colonne = colonne;
        Random random = new Random();
        for (int i = 0; i < righe; i++) {
            for (int j = 0; j < colonne; j++) {
                int generato = random.nextInt(5);
                tab[i][j] = generato;
            }
        }
    }


    public void reset() {
        Random random = new Random();
        for (int i = 0; i < righe; i++) {
            for (int j = 0; j < colonne; j++) {
                int generato = random.nextInt(5);
                tab[i][j] = generato;
            }
        }
        if(righe == 10)this.mosse = 20;
        else this.mosse = 10;
    }

    public boolean vittoria() {
        boolean isWinner = true;
        int firstSquare = tab[0][0];
        for (int i = 0; i < righe; i++) {
            for (int j = 0; j < colonne; j++) {
                if (firstSquare != tab[i][j]) {
                    isWinner = false;
                }
            }
        }
        return isWinner;
    }

    public boolean mossa(int coloreNuovo, int coloreVecchio) {//effettua la mossa richiamando il metodo ricorsivo
        if (mosse <= 0) {
            return false;
        } else {
            if (coloreNuovo != coloreVecchio) {
                ricorsione(coloreVecchio, coloreNuovo, 0, 0);
                if (vittoria()) {
                    return true;
                }
            }
        }
        mosse--;
        return false;
    }


    public void ricorsione(int vecchioColore, int nuovoColore, int x, int y)//metodo ricorsivo per cambiare di colore le celle
    {
        if (x >= 0 && x < righe && y >= 0 && y < colonne) {
            int coloreCella = tab[x][y];
            if (coloreCella == vecchioColore) {
                tab[x][y] = nuovoColore;
                ricorsione(vecchioColore, nuovoColore, x - 1, y);
                ricorsione(vecchioColore, nuovoColore, x, y + 1);
                ricorsione(vecchioColore, nuovoColore, x + 1, y);
                ricorsione(vecchioColore, nuovoColore, x, y - 1);

            }
        }
    }


}
