package com.example.fillzone;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ActivityScelta extends AppCompatActivity {

    public static final String EXTRA_PARTITA = "com.example.andre.fillzone.ActivityScelta.EXTRA_PARTITA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scelta);
        TextView descrizione = findViewById(R.id.textViewSpiegazione);
        descrizione.setText(R.string.descrizione);
        final MediaPlayer mp2 = MediaPlayer.create(this, R.raw.jump);

        Button bottone5x5 = findViewById(R.id.button10x10);
        Button bottone4x4 = findViewById(R.id.button5x5);
        bottone4x4.setVisibility(70);
        bottone5x5.setVisibility(70);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                bottone4x4.setVisibility(0);
                bottone5x5.setVisibility(0);
                translate(bottone4x4);
                translate2(bottone5x5);

            }
        },6500);

        bottone5x5.setOnClickListener(
                (View v) -> {
                    int scelta = 10;
                    mp2.start();
                    Intent intent = new Intent(this, MainActivity.class);//intent che permette di iniziare una partita contro la cpu
                    intent.putExtra(EXTRA_PARTITA, scelta);
                    startActivity(intent);

                }
        );

        bottone4x4.setOnClickListener(
                (View v) -> {
                    int scelta = 5;
                    mp2.start();
                    Intent intent = new Intent(this, MainActivity.class);//intent che permette di iniziare una partita contro la cpu
                    intent.putExtra(EXTRA_PARTITA, scelta);
                    startActivity(intent);

                }
        );
    }

    public ObjectAnimator trasl = new ObjectAnimator();

    public void translate(Button bottone) {
        trasl = ObjectAnimator.ofFloat(bottone, "translationX", 0f, 350f);
        trasl.setDuration(500);
        trasl.start();
    }

    public void translate2(Button bottone) {
        trasl = ObjectAnimator.ofFloat(bottone, "translationX", 0f, -350f);
        trasl.setDuration(500);
        trasl.start();
    }
}
