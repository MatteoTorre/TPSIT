## Andrea Stocco 4ID

# PROGETTO ANDROID: FillZone

Il progetto è  stato suddiviso in:
* *grafica*
* *codice*

### Grafica:
Sono stati implementati diversi layout per le varie schermate di gioco:
- activity_10x10: layout che corrisponde alla schermata di gioco vera e propria, formata da 10 righe e da 10 colonne;
- activity_5x5: layout che corrisponde alla schermata di gioco vera e propria, formata da 5 righe e da 5 colonne;
- activity_scelta: schermata in cui vengono mostrate le regole di gioco e dove l'utente sceglie la modalità di gioco;
- dialog_demo: layout per il dialog di vittoria e sconfitta;

## Codice:
Il codice è stato diviso in tre activity:
- ActivityScelta: activity per la scelta della partita (se layout 5x5 o 10x10);
- FillZone: questo è il "cervello" dell'applicazione che controlla l'eventuale vincitore, gestisce la colorazione delle celle e i vari reset;
- MainActivity:  activity effettiva di gioco in cui l'utente può giocare in un 5x5 o in 10x10, con relativo decremento delle mosse;
